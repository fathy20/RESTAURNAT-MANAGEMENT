# Restaurant-Management-System
<h1>Login Form</h1>
<img src = "Screenshots/Login Form.PNG">
<br/><br/>
<h1>Main Form</h1>
<img src = "Screenshots/Mainfrm.PNG">
<h1>Categories Page</h1>
<img src = "Screenshots/category.PNG">
<h1>Add New Category Page</h1>
<img src = "Screenshots/addcategory.PNG">
<h1>Tables Page</h1>
<img src = "Screenshots/tablelist.PNG">
<h1>Add New Table Page</h1>
<img src = "Screenshots/addtable.PNG">
<h1>Staff Page</h1>
<img src = "Screenshots/staff.PNG">
<h1>Add New Item to Staff Page</h1>
<img src = "Screenshots/staffadd.PNG">
<h1>Product Page</h1>
<img src = "Screenshots/product.PNG">
<h1>Add New Item to Product Page</h1>
<img src = "Screenshots/productadd.PNG">