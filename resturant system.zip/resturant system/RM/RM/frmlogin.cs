﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;

namespace RM
{
    public partial class frmlogin : Form
    {
        public frmlogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "")
            {
                System.Windows.Forms. MessageBox.Show("Enter the user name");

            }else if (txtPass.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Enter the password");
            }
            else
            {
                try
                    
                {
                    SqlConnection con = new SqlConnection("Data Source=LAPTOP-761BUVSO\\SQLEXPRESS;Initial Catalog=login;Integrated Security=True"); 
                    SqlCommand cmd = new SqlCommand ("select* from login where username = @username and password =@password ", con);
                    cmd.Parameters.AddWithValue("@username", txtUser.Text);
                    cmd.Parameters.AddWithValue("@password", txtPass.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        System.Windows.Forms.MessageBox.Show("login successfull");
                    }

                    else
                    {
                    
                       System.Windows.Forms.MessageBox.Show("username or password is invalid");
                    }
                }
                catch( Exception ex) {
                    System.Windows.Forms.MessageBox.Show("" + ex);
                }
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
          //  Application.Run(new main());
            //frmlogin.Hide();
        }

        private void frmlogin_Load(object sender, EventArgs e)
        {

        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
