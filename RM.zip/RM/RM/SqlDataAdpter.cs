﻿namespace RM
{
    internal class SqlDataAdpter
    {
    }
}