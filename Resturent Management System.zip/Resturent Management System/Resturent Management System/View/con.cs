﻿using System;

namespace Resturent_Management_System.View
{
    internal class con
    {
        internal static void Close()
        {
            throw new NotImplementedException();
        }

        internal static void Open()
        {
            throw new NotImplementedException();
        }
    }
}