﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Resturent_Management_System.Model
{
    public partial class frmCategoryAdd : sampleAdd
    {

        public frmCategoryAdd()
        {
            InitializeComponent();
        }

        private void lblheader_Click(object sender, EventArgs e)
        {

        }

        private void frmCategoryAdd_Load(object sender, EventArgs e)
        {

        }

        public int id = 0;
        public override void button1_Click(object sender, EventArgs e)
        {

            // Assuming 'txtCategoryName' and 'txtCategorySr#' are the names of the text boxes on your form
            string categoryName = textBox1.Text;
            string categorySrNumber = textBox2.Text;

            string connString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\amarx\\Documents\\AMARY.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False";
            string query = "";

            if (id == 0) // If 'id' is 0, it's a new category
            {
                query = "INSERT INTO [dbo].[category] ([cat_name], [cat_sr#]) VALUES (@CategoryName, @CategorySrNumber)";
            }
            else // If 'id' is not 0, update the existing category
            {
                query = "UPDATE [dbo].[category] SET [cat_name] = @CategoryName, [cat_sr#] = @CategorySrNumber WHERE [cat-Id] = @ID";
            }

            using (SqlConnection connection = new SqlConnection(connString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@ID", id);
                        command.Parameters.AddWithValue("@CategoryName", categoryName);
                        command.Parameters.AddWithValue("@CategorySrNumber", categorySrNumber);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Category saved successfully.");
                            // Reset form fields and 'id' here if necessary
                            textBox1.Clear();
                            textBox2.Clear();
                            id = 0; // Reset 'id' if necessary
                        }
                        else
                        {
                            MessageBox.Show("No rows affected. Check your data or query.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }

} 

