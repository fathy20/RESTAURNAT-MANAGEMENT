﻿using Resturent_Management_System.View;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Resturent_Management_System.Model
{
    public partial class frmStaffAdd : sampleAdd
    {

        public void PopulateStaffList()
        {
            
        }
        Functions Con;
        public frmStaffAdd()
        {
            InitializeComponent();
            Con = new Functions();
        }
        public int id = 0;
        private void ShowStaf_ser()
        {

            //string query = "SELECT [staf_name], [staf_phone], [staf_rule] FROM staff_list";
            //dataGridView.DataSource = Con.GetData(query);

        }

        private void frmStaffAdd_Load(object sender, EventArgs e)
        {
            
        }
        
        public override void button1_Click(object sender, EventArgs e)
        {

            // Assuming 'txtName', 'txtPhone', and 'txtRule' are the names of the text boxes on your form.
            string name = txtName.Text;
            string phone = textBox2.Text;
            string rule = comboBox1.Text;

            string connString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\amarx\\Documents\\AMARY.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False";
            string query = "";

            if (id == 0) // Assuming 'id' is 0 when adding a new staff member
            {
                query = "INSERT INTO staff_list([staf_name], [staf_phone], [staf_rule]) VALUES (@Name, @Phone, @Rule)";
            }
            else // 'id' is not 0 when updating an existing staff member
            {
                query = "UPDATE staff_list SET [staf_name] = @Name, [staf_phone] = @Phone, [staf_rule] = @Rule WHERE [staf_ser#] = @ID";
            }

            using (SqlConnection connection = new SqlConnection(connString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@ID", id);
                        command.Parameters.AddWithValue("@Name", name); // Use the value from the form
                        command.Parameters.AddWithValue("@Phone", phone); // Use the value from the form
                        command.Parameters.AddWithValue("@Rule", rule); // Use the value from the form

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Saved Successfully...");
                            // Reset form fields and 'id' here if necessary
                            txtName.Clear();
                            textBox2.Clear();
                           // comboBox1.Clear();
                            // Reset 'id' if necessary
                        }
                        else
                        {
                            MessageBox.Show("No rows affected. Check your data or query.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
