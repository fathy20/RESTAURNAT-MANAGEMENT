﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Resturent_Management_System.Model
{
    public partial class frmProductAdd : sampleAdd

    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\amarx\Documents\AMARY.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False";
        public frmProductAdd()
        {
            InitializeComponent();
        }
        public int id = 0;
        public int cID = 0;
        string filepath;
        Byte[] imageByteArray;



        private void btnbrws_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images(.jpg,.png)|*.png; *.jpg";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string filepath = ofd.FileName;
                pictureBox2.Image = new Bitmap(filepath);
            }


        }

        public Image GetImage()
        {
            return pictureBox2.Image;
        }

        private void frmProductAdd_Load(object sender, EventArgs e)
        {
            string qry = "Select catID 'id', catName 'name' from catalog ";
            mainclass.CBFill(qry,cbCat);

            if(cID > 0)
            {
                cbCat.SelectedValue = cID;
            }
            if(id > 0)
            {
                forUpdate();
            }
        }

        public override void button1_Click(object sender, EventArgs e)
        {
            // Get data from the form controls
            string productName = textBox1.Text;
            decimal productPrice = Convert.ToDecimal(textBox2.Text);

            // SQL query to insert data into product_list table
            string query = "INSERT INTO product_list (pro_name, pro_price) VALUES (@ProductName, @ProductPrice)";

            try
            {
                // Open a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Create a SqlCommand object with the SQL query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the SQL query to avoid SQL injection
                        command.Parameters.AddWithValue("@ProductName", productName);
                        command.Parameters.AddWithValue("@ProductPrice", productPrice);

                        // Execute the SQL query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Product added successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add product!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }
        private void forUpdate()
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbCat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
