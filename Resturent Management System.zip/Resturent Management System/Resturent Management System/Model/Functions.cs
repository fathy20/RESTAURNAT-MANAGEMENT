﻿using System;

namespace Resturent_Management_System.Model
{
    internal class Functions
    {
        internal object GetData(string query)
        {
            throw new NotImplementedException();
        }
    }
}