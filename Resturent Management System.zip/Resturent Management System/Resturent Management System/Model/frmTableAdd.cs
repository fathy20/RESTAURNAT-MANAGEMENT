﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Resturent_Management_System.Model
{
    public partial class frmTableAdd : sampleAdd
    {
        // Establish connection string
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\amarx\\Documents\\AMARY.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False";

        public frmTableAdd()
        {
            InitializeComponent();
        }
        public int id = 0;

        public override void button1_Click(object sender, EventArgs e)
        {

            string qry = "";

            if (id == 0)
            {
                qry = "INSERT INTO Tables (tab_name) VALUES (@Name)";
            }
            else
            {
                qry = "UPDATE Tables SET tab_name = @Name WHERE tab_ser# = @id";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(qry, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    command.Parameters.AddWithValue("@Name", textBox1.Text);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Saved Successfully...");
                        id = 0;
                        textBox1.Text = "";
                        textBox1.Focus();
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void frmTableAdd_Load(object sender, EventArgs e)
        {

     
        
        }
    }
}
