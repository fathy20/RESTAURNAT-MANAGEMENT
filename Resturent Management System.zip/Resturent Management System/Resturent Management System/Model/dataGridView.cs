﻿namespace Resturent_Management_System.Model
{
    internal class dataGridView
    {
        public static object DataSource { get; internal set; }
    }
}