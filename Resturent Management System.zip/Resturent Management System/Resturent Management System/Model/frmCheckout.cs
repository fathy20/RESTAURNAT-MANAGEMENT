﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Resturent_Management_System.Model
{
    public partial class frmCheckout : sampleAdd
    {
        public frmCheckout()
        {
            InitializeComponent();
        }
        public double amt;
        public int mainID = 0;
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtreceived_TextChanged(object sender, EventArgs e)
        {
            double amt = 0;
            double receipt = 0;
            double change = 0;

            double.TryParse(txtbillamount.Text, out amt);
            double.TryParse(txtreceived.Text, out receipt);

            change = Math.Abs(amt - receipt);
            btnChange.Text = change.ToString();

        }
        public override void button1_Click(object sender, EventArgs e)
        {
            
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\amarx\\Documents\\AMARY.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=False";
            string qry = @"UPDATE [dbo].[BillTbl] 
                   SET [UName] = @UName, [BDate] = @BDate, [BAmount] = @BAmount 
                   WHERE [BNum] = @BNum";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(qry, con))
                {
                    cmd.Parameters.AddWithValue("@BNum", mainID); 
                    cmd.Parameters.AddWithValue("@UName", "YourUserName"); 
                    cmd.Parameters.AddWithValue("@BDate", DateTime.Now); 
                    cmd.Parameters.AddWithValue("@BAmount", txtbillamount.Text);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Saved Successfully");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Update failed.");
                    }
                }
            }


        }

        private void frmCheckout_Load(object sender, EventArgs e)
        {
            txtbillamount.Text = amt.ToString();
        }

        private void txtbillamount_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnChange_TextChanged(object sender, EventArgs e)
        {

        }

        private void fetchProducts()
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }
    }
}
